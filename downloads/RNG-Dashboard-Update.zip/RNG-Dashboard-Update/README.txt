RNG Dashboard Update - run on your SERVER PC.

1. Extract this entire ZIP.
2. Double-click Apply-Dashboard-Update.cmd.
3. Select the EXISTING dashboard program folder containing next_app.
4. When the server reopens, refresh/reopen the app on your PC and phone.

PC home fits standard desktop/laptop windows, with a 3-by-3 navigation grid
including Log out. Longer note lists scroll inside their panel rather than
making the entire dashboard scroll. All notes remain available.
The upper branding bar is removed. PC pages have Log out beside their
navigation tabs; phones have Log out at the end of the bottom navigation.
Swipe that bar horizontally to reach it. All pages have a dark navy backdrop
with subtle grid/line texture and light cards for readable forms and tables.

This update replaces frontend program files only. It does not read or change
your database, uploads, login password, report files, icons or Tailscale settings.
No Setup, CSV import, credentials, dependencies or icon reinstall is needed.
The previous navy-logo or phone layout update must already be installed.
Program version checks run before changes; old program files are backed up.
If the server does not reopen after an error, use its existing desktop shortcut.

Browser checks cover PC/phone layout, navigation, logout and long note lists.
Native Windows updater execution still needs verification on your server.
