RNG Financial and Agenda Update - run on the SERVER PC.

1. Extract the entire ZIP.
2. Double-click Apply-Financial-Update.cmd.
3. Select your EXISTING program folder containing next_app.
4. When the server reopens, refresh the app on your PC and phone.

New meeting agendas default to Not Raised and Not Started. Previously saved
nonblank statuses are preserved; existing status colors remain available.

Financial now has a Project contract upload beside the budget (below it on
phones). Files are up to 5 MB each and 20 MB total per project. View, Download,
Share and confirmed Remove are available. Uploads/removals are drafts until
Save financial. Your original file bytes are stored in the local database;
they are fetched only when viewed/downloaded, not during every login.

Financial automatic dates contain only Solar Hijri year/month/day, without
AP. Dates remain editable. Existing AP suffixes are cleaned in the editor;
Save financial keeps the corrected date. No live records are bulk rewritten.

The updater changes program files only. It does not read or replace your
database, uploaded files, credentials, icons or Tailscale configuration.
No Setup, CSV import, dependency installation or icon reinstall is needed.
Program hashes are checked and old program files are backed up before changes.
If the app does not reopen after an error, use the existing desktop shortcut.

Contracts can be opened/downloaded from Financial; they are not embedded
inside the generated transaction PDF. Existing report layouts remain unchanged.
PC/phone and API checks cover file integrity, new defaults and editable dates.
Native Windows updater execution still needs verification on the actual server.
