RNG Logo update - run on your SERVER PC only.

1. Extract this entire ZIP.
2. Double-click Apply-Logo-Update.cmd.
3. In the folder picker, choose your EXISTING installed dashboard folder:
   the folder containing next_app (not this update folder).
4. Wait for the dashboard to reopen.

No Setup rerun, CSV import, credentials or database changes are needed.
The updater checks program versions, saves copies of old program files, and
restarts only the dashboard process from the selected installation.

On your phone and other PC: close the app and refresh its existing Tailscale
HTTPS address. If the installed icon stays old, remove only the app shortcut
and install the same address again through Chrome/Edge. Your records remain
on the server. Do not delete the server installation or AppData folder.

If a taskbar icon stays old on Windows, unpin and pin the refreshed app again.
A standalone Windows ICO is included as RNG.ico for optional shortcut settings.

If the updater reports a version mismatch, nothing is replaced. Keep the
installation and share the error text. If the app does not reopen after an
update error, use your existing desktop shortcut. Native Windows execution
requires verification on your server; API/assets and archive integrity have
been tested separately.
