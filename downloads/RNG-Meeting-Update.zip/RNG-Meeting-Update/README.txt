RNG Meeting Status Update - run on the SERVER PC.

1. Extract the entire ZIP.
2. Double-click Apply-Meeting-Update.cmd.
3. Select your EXISTING program folder containing next_app.
4. After the app reopens, refresh the same app address on PC and phone.

Meeting agenda badges and selected status controls now use:
Raised / Done: light green
Not Raised / Stopped: red
Not Started: gray
In Progress: yellow

All eleven NEW agendas start as Not Raised / Not Started. Previously saved
nonblank statuses are preserved, including older capitalization variants.
Blank legacy statuses use the new defaults in the editor; Save meeting
stores them. Defaults pending saving are marked as unsaved so PDF exports
continue to reflect saved records. PDF layouts are otherwise unchanged.
Unknown legacy statuses remain available instead of being silently replaced.

The update includes prior warehouse multi-table PDF support and does not
read or replace your database, uploads, login credentials or Tailscale settings.
No Setup, CSV import, dependencies or icon reinstall is required.
Existing program files are checked and backed up before replacement.
If the app does not reopen after an error, use its existing desktop shortcut.

PC/phone browser checks cover all colors, new defaults, existing statuses,
and saving/reopening. Native Windows updater execution still needs verification
on your actual server.
