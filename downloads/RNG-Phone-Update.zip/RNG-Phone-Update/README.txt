RNG Phone Layout Update - run on the SERVER PC.

1. Extract the entire ZIP.
2. Double-click Apply-Phone-Update.cmd.
3. Select your EXISTING installed dashboard folder containing next_app.
4. After the server reopens, close/reopen the app on your PHONE and refresh
   its existing Tailscale HTTPS address.

This update only replaces frontend program files. Phone styles require a
touch screen with a smaller side at most 700px and viewport at most 1000px,
including landscape. Narrow desktop windows do not activate these changes.
Desktop layouts are unchanged. The BOM table becomes editable item cards
on phones; saved data, calculations and PDFs retain their existing format.
The login fits ordinary phone screens, the bottom navigation and home tiles
are slightly smaller, and sticky notes use a little less space.

No Setup, credentials, CSV import, icon reinstall or Tailscale changes.
Your database and uploaded files are not read or replaced by this updater.
The previous navy-logo update must already be installed. Modified or
unexpected program files make the updater stop without replacing files.
Old program copies are saved in your private AppData program-updates folder.
If the server does not reopen after an error, use its existing desktop shortcut.

Browser checks cover PC and phone layouts, phone BOM edits, saving and PDFs.
Native Windows updater execution still needs verification on your server.
