RNG Warehouse Update - run on the SERVER PC.

1. Extract the entire ZIP.
2. Double-click Apply-Warehouse-Update.cmd.
3. Select the EXISTING program folder containing next_app.
4. When the app reopens, refresh it on your PC and phone.

Warehouse cards now have Add another table below their items.
Each click adds 10 new rows. Existing table entries are preserved.
The page moves to the added table. Save report stores every table.
Download PDF and Share PDF include one original A5 landscape page per table,
with the same request metadata, logo, signatures and approvals on each page.
Older cards without extra tables remain compatible and retain one-page exports.

The updater replaces program files only. It does not read or replace your
database, uploaded files, credentials, icons or Tailscale configuration.
No Setup, CSV import, new dependencies or app reinstall is required.
Supported program versions: previous navy-logo, phone-layout or midnight update.
Version checks precede file replacement, and old program files are backed up.
If the server does not reopen after an error, use its existing desktop shortcut.

Browser tests cover PC/phone, added tables, save/reopen, and both PDF actions.
Native Windows update execution still needs verification on your server.
